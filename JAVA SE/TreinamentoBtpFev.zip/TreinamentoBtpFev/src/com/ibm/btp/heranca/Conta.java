package com.ibm.btp.heranca;

import com.ibm.btp.model.Client;

public class Conta {
	
	private double saldo;
	private int numero;
	private Client titular;
	
	public Conta(){
		
	}
	
	public Conta(double saldo, int numero, Client titular) {
		super();
		this.saldo = saldo;
		this.numero = numero;
		this.titular = titular;
	}
	
	public double consultaSaldo(){
		return saldo;
	}
	
	public boolean sacar(double valor){
		return true;
	}
	
	private boolean depositar(double valor){
		return true;
	}
	/**
	 * @return the saldo
	 */
	public double getSaldo() {
		return saldo;
	}
	/**
	 * @param saldo the saldo to set
	 */
	public void setSaldo(double saldo) {
		this.saldo = saldo;
	}
	/**
	 * @return the numero
	 */
	public int getNumero() {
		return numero;
	}
	/**
	 * @param numero the numero to set
	 */
	public void setNumero(int numero) {
		this.numero = numero;
	}
	/**
	 * @return the titular
	 */
	public Client getTitular() {
		return titular;
	}
	/**
	 * @param titular the titular to set
	 */
	public void setTitular(Client titular) {
		this.titular = titular;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "ContaConcreta [saldo=" + saldo + ", numero=" + numero
				+ ", titular=" + titular + "]";
	}
	
	
	
}
