package com.ibm.btp.heranca;

public class HerancaTeste {
	public static void main(String args[]){
		Conta conta = new Conta(500, 1, null);
		ContaEspecial contaEsp = new ContaEspecial(50,400, 1, null);
		
		System.out.println("Saldo conta " + conta.consultaSaldo());
		System.out.println("Saldo conta especial " + contaEsp.consultaSaldo());		
	}
}
