package com.ibm.btp.heranca;

import com.ibm.btp.model.Client;

public class ContaEspecial extends Conta{
	
	private double limite;
	
	public ContaEspecial(double limite,
			double saldo, int conta, Client titular){
		super(saldo, conta, titular);
		this.limite = limite;
	}
	
	public double consultaLimite(){
		return getLimite();
	}

	@Override
	public double consultaSaldo(){
		return super.consultaSaldo() + limite;
	}
	
	/**
	 * @return the limite
	 */
	public double getLimite() {
		return limite;
	}

	/**
	 * @param limite the limite to set
	 */
	public void setLimite(double limite) {
		this.limite = limite;
	}
	
	
}
