package com.ibm.btp.hierarquia;

import com.ibm.btp.model.Client;

public abstract class Conta {
	
	private double saldo;
	private int numero;
	private Client titular; 
	
	public Conta(){
		
	}
	
	public Conta(double saldo, int numero, Client titular) {
		super();
		this.saldo  = saldo;
		this.numero = numero;
		this.titular = titular;
	}
	
	public abstract double consultaSaldo();
	
	public abstract boolean depositar(double valor);
	
	public abstract boolean sacar(double valor);

	/**
	 * @return the saldo
	 */
	public double getSaldo() {
		return saldo;
	}

	/**
	 * @param saldo the saldo to set
	 */
	public void setSaldo(double saldo) {
		this.saldo = saldo;
	}

	/**
	 * @return the numero
	 */
	public int getNumero() {
		return numero;
	}

	/**
	 * @param numero the numero to set
	 */
	public void setNumero(int numero) {
		this.numero = numero;
	}

	/**
	 * @return the titular
	 */
	public Client getTitular() {
		return titular;
	}

	/**
	 * @param titular the titular to set
	 */
	public void setTitular(Client titular) {
		this.titular = titular;
	}

}
