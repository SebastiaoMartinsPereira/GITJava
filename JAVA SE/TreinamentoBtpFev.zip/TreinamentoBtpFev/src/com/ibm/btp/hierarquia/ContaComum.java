package com.ibm.btp.hierarquia;

import com.ibm.btp.model.Client;

public class ContaComum extends Conta {

	public ContaComum(){
		
	}
	
	public ContaComum(double saldo, int numero, Client titular) {
		super(saldo, numero, titular);
		//outra forma:
//		super.setNumero(numero);
//		super.setSaldo(saldo);
//		super.setTitular(titular);
	}
	
	@Override
	public double consultaSaldo() {
		return super.getSaldo(); 
	}

	@Override
	public boolean sacar(double valor) {
		if(valor<=super.getSaldo()) { 
			super.setSaldo(super.getSaldo()-valor);
			return true;
		}
		return false;
	}

	@Override
	public boolean depositar(double valor) {
		if(valor<0) return false;
		super.setSaldo(super.getSaldo()+valor);
		return true;
	}
	
	
}
