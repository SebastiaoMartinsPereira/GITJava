package com.ibm.btp.hierarquia;


public class TestePolimorfismo {

	public static void main(String args[]){
		Conta conta = new ContaComum(500, 1, null);
		Conta contaEsp = new ContaEspecial(200,500, 1, null);
		
		
		if(realizarSaque(conta, 600)){
		System.out.println("Saldo conta comum" + 
			conta.consultaSaldo());
		}else{
			System.out.println("Nao foi possivel sacar");
		}
		if(realizarSaque(contaEsp, 600)){
			System.out.println("Saldo conta especial " + 
			contaEsp.consultaSaldo());		
		}else{
			System.out.println("Nao foi possivel sacar");
		}
	}
	
	private static boolean realizarSaque(Conta minhaConta, double valor){
		return minhaConta.sacar(valor);
	}
}
