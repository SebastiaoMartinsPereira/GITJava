package com.ibm.btp.intro.loops;

import java.util.Scanner;

import com.ibm.btp.model.Client;

public class LoopsTest {
	
	public static void main(String args[]){
		
		Scanner scan = new Scanner(System.in);
		int i;
		boolean control = false;
		while(!control){
			System.out.println("Digite um numero"
					+ " positivo inteiro ou -1"
					+ " para encerrar o programa");
			i = scan.nextInt();
			if(i==-1){
				control = true;
				break;
			}
			test2(i);
		}
		
		System.out.println("Finalizando o programa");

		
		//double j = Math.sqrt(i);
		
//		System.out.println("A raiz quadrada de " +
//		i + "� " + j);
		
		//test6(i);
		//int[] randomArray = new int[4];
//		int[] randomArray = {1,6,7,8,20, 40, 67, 45, 23};
//		printArray(randomArray);
		
		//Client[] randomArray2 = new Client[7];
		scan.close();
		
	}
	
	void test1(int i){
		 //if exige uma condicao booleana
		if(i==1){
			System.out.println("Igual a 1");
		}
		else if(i==2){
			System.out.println("Igual a 2");
		}
		else{
			System.out.println("Outra opcao");
		}
	}
	
	public static void test2(int i){
		if(i>10){
			System.out.println("maior q 10");
		}
		else if(isEven(i)){
			System.out.println("eh par");
		}
	}
	
	public static void test3(int i){
		 int j=0;
		 while(j<i){
			 System.out.println(j);
			 //j++;
		 }
	}
	
	public static void test4(int i){
		 int j=0;
		 do{
			 //mesmo sem incrementar ele nao daria loop infinito pra i=0
			 System.out.println(j++);
		 }while(j<i);
	}
	
	public static void test5(int i){
		 int j,k;
		 for(j=0, k=20; j<i && k>10; j++, k = k-2){
			 System.out.println(j + " " + k);
		 }
	}
	
	public static void test6(int i){
		 int j,k;
		 for(j=0; j<i; j++){
			 for(k=0; k<=j; k++){
				 System.out.print(k + " ");
			 }
			 System.out.println();
		 }
	}
	
	public static void test7(int i){
		
	}
	public static void printArray(int[] myArray){
		int length = myArray.length;
		for(int i=0;i<length;i++){
			System.out.print(myArray[i] + " ");
		}
		
	}
	
	public static void printArray2(int[] myArray){
		for(int elementoCorrente : myArray){
			System.out.print(elementoCorrente);
			if(elementoCorrente==myArray[2]){
				myArray[2] = 8;
			}
		}
	}
	
	
	public static boolean isEven(int i){
//		int resto = i%2;
//		if(resto==0){
//			return true;
//		}//		else{
//			return false;
//		}

		return (i%2)==0;
	}
	
	
}
