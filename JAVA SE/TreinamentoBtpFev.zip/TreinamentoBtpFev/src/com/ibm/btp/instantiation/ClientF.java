package com.ibm.btp.instantiation;



	public class ClientF {

		/*
		 * Declarando atributos como privados: acesso somente dentro da classe, assim nenhum codigo externo pode 
		 * modificar os valores dos atributos indevidamente
		 */
		private String name;
		
		private String cpf;
		
		private String telefone;
		
		private int idade;
		
		private double saldo;
		
		
		private ClientF(String name, String cpf, String telefone, 
				int idade, double saldo){
			//note o uso do this para acessar os atributos da classe e diferenciar dos parametros de mesmo nome
			this.name = name;
			this.cpf = cpf;
			this.telefone = telefone;
			this.idade = idade;
			this.saldo = saldo;
		}

		/* (non-Javadoc)
		 * @see java.lang.Object#toString()
		 */
		@Override
		public String toString() {
			return "ClientF [name=" + name + ", cpf=" + cpf + ", telefone="
					+ telefone + ", idade=" + idade + ", saldo=" + saldo + "]";
		}

		
		/**
		 * @return the name
		 */
		public String getName() {
			return name;
		}

		/**
		 * @param name the name to set
		 */
		public void setName(String name) {
			this.name = name;
		}

		/**
		 * @return the cpf
		 */
		public String getCpf() {
			return cpf;
		}

		/**
		 * @param cpf the cpf to set
		 */
		public void setCpf(String cpf) {
			this.cpf = cpf;
		}

		/**
		 * @return the telefone
		 */
		public String getTelefone() {
			return telefone;
		}

		/**
		 * @param telefone the telefone to set
		 */
		public void setTelefone(String telefone) {
			this.telefone = telefone;
		}

		/**
		 * @return the idade
		 */
		public int getIdade() {
			return idade;
		}

		/**
		 * @param idade the idade to set
		 */
		public void setIdade(int idade) {
			this.idade = idade;
		}

		/**
		 * @return the saldo
		 */
		public double getSaldo() {
			return saldo;
		}

		/**
		 * @param saldo the saldo to set
		 */
		public void setSaldo(double saldo) {
			this.saldo = saldo;
		}
		
		
	}

