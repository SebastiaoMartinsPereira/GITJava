package com.ibm.btp.instantiation;

public class InstantiationTest {

	public static void main(String[] args) {
		
		//gera NPE - NullPointerException
		//ClientA newClientA=null;
		//newClientA.setName("Joao");
		//newClientA = new ClientA();
		
		//Construtor herdado da classe object
		ClientA clienteA = new ClientA();
		System.out.println("cliente A " + clienteA.toString());
		
		ClientB clienteB = new ClientB();
		System.out.println("cliente B " + clienteB.toString());
		
		ClientC clienteC = new ClientC();
		System.out.println("cliente C " + clienteC.toString());
		
		ClientD clienteD = new ClientD("Ivo", "3333333", "999999", 
				20, 1000.0);
		System.out.println("cliente D " + clienteD.toString());
		
		//Como ja definimos um construtor que recebe parametros, 
		//e NAO DEFINIMOS explicitamente no codigo da classe ClientD
		//um construtor sem parametros, isso nao � valido
		//ClientD clienteD2 = new ClientD();
		
		ClientE clienteE = new ClientE("Ivo", "3333333", "999999", 
				20, 1000.0);
		System.out.println("cliente E " + clienteE.toString());
		
		ClientE clienteE2 = new ClientE();
		System.out.println("cliente E2 " + clienteE2.toString());
		
		//atributo privado - nao consigo acessar fora da classe E
		//String clienteName = clienteE2.name;
		
		String clientName = clienteE.getName();
		System.out.println("O nome do cliente E � " + clientName);

		
		//ClientF clienteF = new ClientF();


	}

}
